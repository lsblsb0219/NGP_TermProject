#include <iostream>
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <glm.hpp>
#include <ext.hpp>
#include <gtc/matrix_transform.hpp>
#include <Windows.h>

#include "..\Common.h"

#define SERVERPORT 9000
#define BUFSIZE    1024

#define MAX_PLAYER 3	// ���� �ο� ����
#define BLOCK_NUM 19	// ��ֹ� ��

typedef struct Bounding_Box {
	float x1, z1, x2, z2;
}BB;

#pragma pack(1)
typedef struct player_packet {
	float x{}, z{}, road[2][2]{},
		speed = 0.0f,
		shake = 1, y_radian = 180.0f, // shake = (��,�ٸ�)ȸ�� ����, radian = �� y�� ȸ�� ����
		y{};
	BB bb{}; //���� ���, ������ �ϴ�
	int shake_dir{}, dir{};
	bool move = false, bump = false; // �����̰� �ִ���(��� �� �̵�)
}Robot;

#pragma pack()
player_packet player_robot[MAX_PLAYER], block_robot[BLOCK_NUM];

HANDLE hGameStartEvent;
HANDLE hWriteEvent[MAX_PLAYER], hReadEvent[MAX_PLAYER], hCountdownEvent[MAX_PLAYER];

void InitBuffer();
BB get_bb(Robot robot);
bool collision(BB obj_a, BB obj_b);

BB goal{ 198.f,149.f,204.f,151.f };

int client_sock_count = 0;	// Ŭ���̾�Ʈ ���� ��
int countdown; // ī��Ʈ�ٿ� ����
int goal_check[MAX_PLAYER]{};

DWORD WINAPI main_thread(LPVOID arg)
{
	SOCKET sock = (SOCKET)arg;
	int retval, client_id = -1;

	// ���� ���� ���
	WaitForSingleObject(hGameStartEvent, INFINITE);

	// ���� ���� ��Ŷ ����
	const char* gameStartMsg = "GAME_START";

	retval = send(sock, gameStartMsg, strlen(gameStartMsg), 0);
	if (retval == SOCKET_ERROR)
		err_display("send()");
	else
		printf("[TCP ����] GAME_START ��Ŷ ���� �Ϸ�\n");

	printf("[Thread] Ŭ���̾�Ʈ ������ ����\n");

	// Ŭ���̾�Ʈ ID�� ����
	retval = recv(sock, (char*)&client_id, sizeof(int), 0);
	if (retval == SOCKET_ERROR)
		err_display("send()");
	
	// recv() �÷��̾� ���� �ޱ� - Robot
	retval = recv(sock, (char*)&player_robot[client_id], sizeof(player_robot[client_id]), 0);
	if (retval == SOCKET_ERROR)
		err_display("recv()");
	SetEvent(hWriteEvent[client_id]);
	WaitForMultipleObjects(MAX_PLAYER, hWriteEvent, TRUE, INFINITE);
	// send() �÷��̾� ���� ������ - Robot[3]
	for (int i = 0; i < MAX_PLAYER; i++) {
		retval = send(sock, (char*)&player_robot[i], sizeof(player_robot[i]), 0);
		if (retval == SOCKET_ERROR)
			err_display("send()");
	}
	printf("[Thread] Ŭ���̾�Ʈ ID(client_%d) ���� �Ϸ�\n", client_id);

	while (countdown >= 0) {
		// send() ī��Ʈ�ٿ� ���� ������		
		WaitForSingleObject(hCountdownEvent[client_id], INFINITE);
		retval = send(sock, (char*)&countdown, sizeof(countdown), 0);
		if (retval == SOCKET_ERROR) {
			err_display("send() countdown");
			break;
		}
		ResetEvent(hCountdownEvent[client_id]);
	}
	ResetEvent(hWriteEvent[client_id]);
	while (goal_check[client_id] == 0) {
		// recv() �÷��̾� ���� �ޱ� - Robot
		retval = recv(sock, (char*)&player_robot[client_id], sizeof(player_robot[client_id]), 0);
		if (retval == SOCKET_ERROR) {
			err_display("recv()");
			printf("�÷��̾� ���� �ޱ�\n");
			break;
		}

		// send() ���� ������ �κ��� ���Դ��� üũ
		if (collision(goal, player_robot[client_id].bb)) {
			for (int i = 0; i < MAX_PLAYER; ++i)
				goal_check[i] = -1;
			goal_check[client_id] = 1;
		}
		SetEvent(hWriteEvent[client_id]);	// �÷��̾� ���� Ȯ��
		WaitForSingleObject(hReadEvent[client_id], INFINITE);
		retval = send(sock, (char*)&goal_check[client_id], sizeof(int), 0);
		if (retval == SOCKET_ERROR) {
			err_display("send()");
			printf("���� üũ ����\n");
			break;
		}
		if (goal_check[client_id] != 0)
			continue;

		// send() �÷��̾� ���� ������ - Robot[3]
		for (int i = 0; i < MAX_PLAYER; i++) {
			retval = send(sock, (char*)&player_robot[i], sizeof(player_robot[i]), 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				printf("�÷��̾� ���� ������\n");
				break;
			}
		}
		ResetEvent(hReadEvent[client_id]);

		// send() �κ� ���� ������ - Robot[19]
		for (int i = 0; i < BLOCK_NUM; ++i) {
			retval = send(sock, (char*)&block_robot[i], sizeof(block_robot[i]), 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				printf("�κ� ���� ������\n");
				break;
			}
		}
	}
	SetEvent(hWriteEvent[client_id]);	// �÷��̾� ���� Ȯ��

	closesocket(sock);
	printf("[Thread] Ŭ���̾�Ʈ ID(client_%d) ������ ����\n", client_id);
	client_sock_count -= 1;

	return 0;
}

DWORD WINAPI update_thread(LPVOID)
{
	InitBuffer();	// ��ֹ� �ʱ� ����

	printf("[Thread] ������Ʈ ������ ����\n");

	// ���� ���� ���
	WaitForSingleObject(hGameStartEvent, INFINITE);

	// ī��Ʈ�ٿ� ����
	countdown = 3;

	// 3, 2, 1, 0, -1 ���� 1�ʸ��� ���ҽ�Ű��
	while (countdown >= -1)
	{
		for (int i = 0; i < MAX_PLAYER; i++)
			SetEvent(hCountdownEvent[i]);
		if (countdown > -1)
			Sleep(1000);   // 1�ʸ��� �� ����
		countdown--;
	}
	while (client_sock_count != 0) {
		for (int i = 0; i < BLOCK_NUM; ++i) {
			block_robot[i].x += sin(glm::radians(block_robot[i].y_radian)) * block_robot[i].speed;
			block_robot[i].z += cos(glm::radians(block_robot[i].y_radian)) * block_robot[i].speed;
			block_robot[i].bb = get_bb(block_robot[i]);
			block_robot[i].shake += block_robot[i].shake_dir * 20 * block_robot[i].speed;
			if (block_robot[i].shake <= -60.0f || block_robot[i].shake >= 60.0f)
				block_robot[i].shake_dir *= -1;
			if ((block_robot[i].road[0][0] < block_robot[i].x and block_robot[i].x < block_robot[i].road[1][0]) ||
				(block_robot[i].road[0][0] > block_robot[i].x and block_robot[i].x > block_robot[i].road[1][0]) ||
				(block_robot[i].road[0][1] < block_robot[i].z and block_robot[i].z < block_robot[i].road[1][1]) ||
				(block_robot[i].road[0][1] > block_robot[i].z and block_robot[i].z > block_robot[i].road[1][1]));
			else
				block_robot[i].y_radian += 180.0f;
			block_robot[i].bb = get_bb(block_robot[i]);
		}
		WaitForMultipleObjects(MAX_PLAYER, hWriteEvent, TRUE, INFINITE);
		for (int id = 0; id < MAX_PLAYER; ++id) {
			for (int i = 0; i < MAX_PLAYER; ++i) {
				if (i == id) continue;
				if (player_robot[id].move && collision(player_robot[i].bb, player_robot[id].bb)) {	// �÷��̾� �� �浹
					player_robot[id].move = false;
					player_robot[id].x -= sin(glm::radians(player_robot[id].y_radian)) * player_robot[id].speed;
					player_robot[id].z -= cos(glm::radians(player_robot[id].y_radian)) * player_robot[id].speed;
					player_robot[id].speed = 0;
					GLfloat radian = atan2(player_robot[id].x - player_robot[i].x, player_robot[id].z - player_robot[i].z);
					player_robot[id].road[0][0] = player_robot[i].x, player_robot[id].road[0][1] = player_robot[i].z;
					player_robot[id].road[1][0] = player_robot[i].x + 2.0f * sin(radian), player_robot[id].road[1][1] = player_robot[i].z + 2.0f * cos(radian);
					player_robot[id].bump = true;
				}
			}
			for (int i = 0; i < BLOCK_NUM; ++i) {
				if (player_robot[id].move && collision(block_robot[i].bb, player_robot[id].bb)) {	// �÷��̾�� ��ֹ� �浹
					player_robot[id].move = false;
					player_robot[id].x -= sin(glm::radians(player_robot[id].y_radian)) * player_robot[id].speed;
					player_robot[id].z -= cos(glm::radians(player_robot[id].y_radian)) * player_robot[id].speed;
					player_robot[id].speed = 0;
					GLfloat radian = atan2(player_robot[id].x - block_robot[i].x, player_robot[id].z - block_robot[i].z);
					player_robot[id].road[0][0] = block_robot[i].x, player_robot[id].road[0][1] = block_robot[i].z;
					player_robot[id].road[1][0] = block_robot[i].x + 2.0f * sin(radian), player_robot[id].road[1][1] = block_robot[i].z + 2.0f * cos(radian);
					player_robot[id].bump = true;
				}
			}
		}		
		for (int i = 0; i < MAX_PLAYER; ++i) {
			ResetEvent(hWriteEvent[i]);
			SetEvent(hReadEvent[i]);
		}
	}

	printf("[Thread] ������Ʈ ������ ����\n");

	for (int i = 0; i < MAX_PLAYER; ++i) {
		CloseHandle(hWriteEvent[i]);
		CloseHandle(hReadEvent[i]);
		CloseHandle(hCountdownEvent[i]);
	}

	return 0;
}

int main(int argc, char* argv[])
{
	int retval;
	DWORD optval = 1; // Nagle ����

	// ���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;

	// ���� ����
	SOCKET listen_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_sock == INVALID_SOCKET) err_quit("socket()");

	// bind()
	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(listen_sock, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) err_quit("bind()");

	// listen()
	retval = listen(listen_sock, SOMAXCONN);
	if (retval == SOCKET_ERROR) err_quit("listen()");

	// CreateEvent()
	hGameStartEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	// ������ ��ſ� ����� ����
	SOCKET client_sock;
	struct sockaddr_in clientaddr;
	int addrlen;
	char buf[BUFSIZE + 1];
	
	// Ŭ���̾�Ʈ ���� ��
	client_sock_count = 0;

	while (true) {
		// �ִ� ���� �ο� �� ����
		if (client_sock_count >= MAX_PLAYER) {
			if (WaitForSingleObject(hGameStartEvent, 0)) {
				printf("\n3�� ���� �Ϸ�\n");
				SetEvent(hGameStartEvent);

				// ������Ʈ ������ ����
				HANDLE hThread = CreateThread(NULL, 0, update_thread, NULL, 0, NULL);
				if (hThread)
					CloseHandle(hThread);

				continue;
			}
			else {
				while (WaitForSingleObject(hGameStartEvent, 0) == WAIT_OBJECT_0);	// ��ȣ�� ���� ������ ���
				continue;
			}
		}
		
		// accept()
		addrlen = sizeof(clientaddr);
		client_sock = accept(listen_sock, (struct sockaddr*)&clientaddr, &addrlen);
		if (client_sock == INVALID_SOCKET) {
			err_display("accept()");
			break;
		}

		// Nagle ����
		setsockopt(client_sock, IPPROTO_TCP, TCP_NODELAY, (char*)&optval, sizeof(optval));

		// ������ Ŭ���̾�Ʈ ���� ���
		char addr[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &clientaddr.sin_addr, addr, sizeof(addr));
		printf("\n[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n",
			addr, ntohs(clientaddr.sin_port));

		// Ŭ���̾�Ʈ�� ID�� ����
		retval = send(client_sock, (char*)&client_sock_count, sizeof(int), 0);
		if (retval == SOCKET_ERROR) {
			err_display("send()");
		}

		// ���� ������ ����
		HANDLE hThread = CreateThread(NULL, 0, main_thread, (LPVOID)client_sock, 0, NULL);
		if (hThread)
			CloseHandle(hThread);
		hWriteEvent[client_sock_count] = CreateEvent(NULL, TRUE, FALSE, NULL);
		hReadEvent[client_sock_count] = CreateEvent(NULL, TRUE, FALSE, NULL);
		hCountdownEvent[client_sock_count] = CreateEvent(NULL, TRUE, FALSE, NULL);

		// client sock count ����
		client_sock_count++;
	}
	
	// �̺�Ʈ �ڵ� �ݱ�
	CloseHandle(hGameStartEvent);

	// ���� �ݱ�
	closesocket(listen_sock);

	// ���� ����
	WSACleanup();
	return 0;
}

void InitBuffer()
{
	block_robot[0].road[0][0] = -203,	block_robot[0].road[0][1] = 140;
	block_robot[0].road[1][0] = -203,	block_robot[0].road[1][1] = -150;

	block_robot[1].road[0][0] = -199,	block_robot[1].road[0][1] = 140;
	block_robot[1].road[1][0] = -199,	block_robot[1].road[1][1] = -150;

	block_robot[2].road[0][0] = -201,	block_robot[2].road[0][1] = 130;
	block_robot[2].road[1][0] = -201,	block_robot[2].road[1][1] = -150;

	block_robot[3].road[0][0] = -202,	block_robot[3].road[0][1] = 0;
	block_robot[3].road[1][0] = -202,	block_robot[3].road[1][1] = 150;

	block_robot[4].road[0][0] = -200,	block_robot[4].road[0][1] = 0;
	block_robot[4].road[1][0] = -200,	block_robot[4].road[1][1] = 150;

	block_robot[5].road[0][0] = -201,	block_robot[5].road[0][1] = 5;
	block_robot[5].road[1][0] = -201,	block_robot[5].road[1][1] = 150;

	block_robot[6].road[0][0] = -195,	block_robot[6].road[0][1] = -153;
	block_robot[6].road[1][0] = -195,	block_robot[6].road[1][1] = -147;

	block_robot[7].road[0][0] = 200,	block_robot[7].road[0][1] = -150;
	block_robot[7].road[1][0] = 190,	block_robot[7].road[1][1] = -150;

	block_robot[8].road[0][0] = 200,	block_robot[8].road[0][1] = -153;
	block_robot[8].road[1][0] = -200,	block_robot[8].road[1][1] = -148;

	block_robot[9].road[0][0] = 200,	block_robot[9].road[0][1] = -152;
	block_robot[9].road[1][0] = -200,	block_robot[9].road[1][1] = -152;

	block_robot[10].road[0][0] = 198,	block_robot[10].road[0][1] = -150;
	block_robot[10].road[1][0] = -198,	block_robot[10].road[1][1] = -150;

	block_robot[11].road[0][0] = 196,	block_robot[11].road[0][1] = -148;
	block_robot[11].road[1][0] = -196,	block_robot[11].road[1][1] = -148;

	block_robot[12].road[0][0] = 198,	block_robot[12].road[0][1] = -110;
	block_robot[12].road[1][0] = 204,	block_robot[12].road[1][1] = -110;

	block_robot[13].road[0][0] = 204,	block_robot[13].road[0][1] = -40;
	block_robot[13].road[1][0] = 198,	block_robot[13].road[1][1] = -40;

	block_robot[14].road[0][0] = 203,	block_robot[14].road[0][1] = -40;
	block_robot[14].road[1][0] = 203,	block_robot[14].road[1][1] = -110;

	block_robot[15].road[0][0] = 199,	block_robot[15].road[0][1] = -40;
	block_robot[15].road[1][0] = 199,	block_robot[15].road[1][1] = 20;

	block_robot[16].road[0][0] = 200,	block_robot[16].road[0][1] = 50;
	block_robot[16].road[1][0] = 200,	block_robot[16].road[1][1] = 140;

	block_robot[17].road[0][0] = 202,	block_robot[17].road[0][1] = 140;
	block_robot[17].road[1][0] = 202,	block_robot[17].road[1][1] = 50;

	block_robot[18].road[0][0] = 201,	block_robot[18].road[0][1] = 148;
	block_robot[18].road[1][0] = 201,	block_robot[18].road[1][1] = 148;
	for (int i = 0; i < BLOCK_NUM; ++i) {
		block_robot[i].x = block_robot[i].road[0][0];
		block_robot[i].z = block_robot[i].road[0][1];
		block_robot[i].speed = 0.2f, block_robot[i].shake_dir = 1;
		if (block_robot[i].road[0][0] < block_robot[i].road[1][0])
			block_robot[i].y_radian = 90.0f;
		if (block_robot[i].road[0][0] > block_robot[i].road[1][0])
			block_robot[i].y_radian = -90.0f;
		if (block_robot[i].road[0][1] < block_robot[i].road[1][1])
			block_robot[i].y_radian = 0.0f;
		if (block_robot[i].road[0][1] > block_robot[i].road[1][1])
			block_robot[i].y_radian = 180.0f;
	}
}

BB get_bb(Robot robot)
{
	glm::mat4 Transform = glm::mat4(1.0f);//��ȯ ��� ���� T
	Transform = glm::translate(Transform, glm::vec3(robot.x, 0.0f, robot.z));
	Transform = glm::rotate(Transform, glm::radians(robot.y_radian), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::vec3 spots[4]{ glm::vec3(-0.3f, 0.0f, 0.1f), glm::vec3(0.3f, 0.0f, 0.1f), glm::vec3(-0.3f, 0.0f, -0.1f), glm::vec3(0.3f, 0.0f, -0.1f) };
	for (int i = 0; i < 4; ++i)
		spots[i] = glm::vec3(Transform * glm::vec4(spots[i], 1.0f));

	BB bounding_box{ spots[0].x, spots[0].z, spots[0].x, spots[0].z };
	for (int i = 1; i < 3; ++i) {
		if (bounding_box.x1 > spots[i].x)
			bounding_box.x1 = spots[i].x;
		if (bounding_box.x2 < spots[i].x)
			bounding_box.x2 = spots[i].x;
		if (bounding_box.z1 > spots[i].z)
			bounding_box.z1 = spots[i].z;
		if (bounding_box.z2 < spots[i].z)
			bounding_box.z2 = spots[i].z;
	}

	return bounding_box;
}
bool collision(BB obj_a, BB obj_b) {
	if (obj_a.x1 > obj_b.x2) return false;
	if (obj_a.x2 < obj_b.x1) return false;
	if (obj_a.z1 > obj_b.z2) return false;
	if (obj_a.z2 < obj_b.z1)return false;

	return true;
}
